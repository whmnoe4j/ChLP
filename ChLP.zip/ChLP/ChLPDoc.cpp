// ChLPDoc.cpp : implementation of the CChLPDoc class
//

#include "stdafx.h"
#include "ChLP.h"

#include "ChLPDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CChLPDoc

IMPLEMENT_DYNCREATE(CChLPDoc, CDocument)

BEGIN_MESSAGE_MAP(CChLPDoc, CDocument)
	//{{AFX_MSG_MAP(CChLPDoc)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CChLPDoc construction/destruction

CChLPDoc::CChLPDoc()
{
	// TODO: add one-time construction code here

}

CChLPDoc::~CChLPDoc()
{
}

BOOL CChLPDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	// TODO: add reinitialization code here
	// (SDI documents will reuse this document)

	return TRUE;
}



/////////////////////////////////////////////////////////////////////////////
// CChLPDoc serialization

void CChLPDoc::Serialize(CArchive& ar)
{
	// CEditView contains an edit control which handles all serialization
	((CEditView*)m_viewList.GetHead())->SerializeRaw(ar);
}

/////////////////////////////////////////////////////////////////////////////
// CChLPDoc diagnostics

#ifdef _DEBUG
void CChLPDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CChLPDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CChLPDoc commands
