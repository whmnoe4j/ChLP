//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by ChLP.rc
//
#define ID_OK                           1
#define ID_CANCEL                       2
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_CHLPTYPE                    129
#define IDD_FILE_ATTRIBUTES             130
#define IDD_GET_DATA                    131
#define IDC_CATEGORY                    1000
#define IDC_EDIT_AUTHOR                 1005
#define IDC_EDIT_YEAR                   1006
#define ID_COMBOBOX_SOURCE              1007
#define IDC_SPIN_YEAR                   1008
#define IDC_SAMPLE                      1009
#define IDC_DATA_STRING                 1010
#define ID_DATA_ATTRIBUTES              32771

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        132
#define _APS_NEXT_COMMAND_VALUE         32772
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
