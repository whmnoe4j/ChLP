// FileAttributes.cpp : implementation file
//

#include "stdafx.h"
#include "ChLP.h"
#include "FileAttributes.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CFileAttributes dialog


CFileAttributes::CFileAttributes(CWnd* pParent /*=NULL*/)
	: CDialog(CFileAttributes::IDD, pParent)
{
	//{{AFX_DATA_INIT(CFileAttributes)
	m_Sample = FALSE;
	m_Year =2016;
	m_Author = _T("");
	m_Category = 0;
	m_Source = _T("");
	//}}AFX_DATA_INIT
}


void CFileAttributes::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CFileAttributes)
	DDX_Control(pDX, ID_COMBOBOX_SOURCE, m_SourceCtrl);
	DDX_Control(pDX, IDC_SPIN_YEAR, m_SpinYear);
	DDX_Check(pDX, IDC_SAMPLE, m_Sample);
	DDX_Text(pDX, IDC_EDIT_YEAR, m_Year);
	DDV_MinMaxInt(pDX, m_Year, 1949, 2050);
	DDX_Text(pDX, IDC_EDIT_AUTHOR, m_Author);
	DDV_MaxChars(pDX, m_Author, 100);
	DDX_Radio(pDX, IDC_CATEGORY, m_Category);
	DDX_CBString(pDX, ID_COMBOBOX_SOURCE, m_Source);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CFileAttributes, CDialog)
	//{{AFX_MSG_MAP(CFileAttributes)
	ON_BN_CLICKED(ID_OK, OnOk)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CFileAttributes message handlers

BOOL CFileAttributes::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	m_SourceCtrl.SetWindowText("���Ŀα�");
	m_SpinYear.SetRange(1949,2050);
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CFileAttributes::OnOk() 
{
	// TODO: Add your control notification handler code here
	UpdateData(TRUE);
	CString msg,Class;
	switch(m_Category){
	case 0:Class="����"; break;
	case 1:Class="��ѧ"; break;
	case 2:Class="Ӣ��"; break;
	case 3:Class="��Ϣ";break;
	case 4:Class="���";break;
	}
	msg.Format("���ߣ�%s;���ࣺ%s;\n������%s;\n����ʱ�䣺%d�꣺\n",m_Author,Class,m_Source,m_Year);
	if(m_Sample)msg+="��Ϊ����";else msg+="����Ϊ����";
	AfxMessageBox(msg);
	CDialog::OnOK();
}
/////////////////////////////////////////////////////////////////////////////
// CGetDataDlg dialog


CGetDataDlg::CGetDataDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CGetDataDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CGetDataDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}

CGetDataDlg::CGetDataDlg(char*Prompt,CWnd* pParent /*=NULL*/)
	: CDialog(CGetDataDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CGetDataDlg)
	DataString=_T("");
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	PromptStr=Prompt;
}


void CGetDataDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CGetDataDlg)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	DDX_Text(pDX, IDC_DATA_STRING, DataString);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CGetDataDlg, CDialog)
	//{{AFX_MSG_MAP(CGetDataDlg)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CGetDataDlg message handlers

BOOL CGetDataDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	SetWindowText(PromptStr);
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

BOOL /*CGetDataDlg::*/GetData(const char *Prompt, CString &Data)
{
	CGetDataDlg dlg((char*)Prompt);
	if(dlg.DoModal()!=IDOK)return FALSE;
	Data=dlg.DataString;
	return TRUE;
}
BOOL GetData(const char *Prompt, int &Data)
{
	CGetDataDlg dlg((char*)Prompt);
	if(dlg.DoModal()!=IDOK)return FALSE;
	dlg.DataString.TrimLeft();
	dlg.DataString.TrimRight();
	Data=atoi((const char*)(dlg.DataString));
	return TRUE;
}
BOOL GetData(const char *Prompt, double &Data)
{
	CGetDataDlg dlg((char*)Prompt);
	if(dlg.DoModal()!=IDOK)return FALSE;
	dlg.DataString.TrimLeft();
	dlg.DataString.TrimRight();
	Data=atof((const char*)(dlg.DataString));
	return TRUE;
}
